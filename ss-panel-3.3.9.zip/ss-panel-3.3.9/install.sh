## Install Composer
curl -sS https://getcomposer.org/installer | php
php composer.phar  install

##
chmod -R 777 storage

##
php xcat createAdmin