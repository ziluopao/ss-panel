<?php


namespace App\Service\Cache;


class Factory
{

}