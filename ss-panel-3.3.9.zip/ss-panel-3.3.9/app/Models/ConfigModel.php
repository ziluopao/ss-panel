<?php


namespace App\Models;


class ConfigModel extends Model
{
    protected $table = "sp_config";
}