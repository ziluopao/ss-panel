<?php


namespace App\Service\Cache;

use App\Services\RedisClient;

class Redis extends Base
{
    public function __construct()
    {

    }

    public function set()
    {
        // TODO: Implement set() method
    }

    public function get()
    {
        // TODO: Implement get() method.
    }
}