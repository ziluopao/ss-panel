<?php


namespace App\Models;


class CheckInLog
{
    protected $table = "ss_checkin_log";
}